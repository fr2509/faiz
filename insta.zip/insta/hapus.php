<?php
include "koneksi.php";
$no=$_GET['no'];
$sql="SELECT * FROM post WHERE no='$no'";
$query=mysqli_query($koneksi, $sql);

while($data = mysqli_fetch_assoc($query)){
    $foto=$data['foto'];
    unlink('images/' .$foto);
}

$sql1="DELETE FROM post WHERE no='$no'";
$query1=mysqli_query($koneksi, $sql1);
if($query1){
    header("location:index.php?hapus=sukses");
}else{
    header("location:index.php?hapus=gagal");
}
?>